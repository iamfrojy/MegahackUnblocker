const express = require("express");
const axios = require("axios");
const rateLimit = require("express-rate-limit");
const basicAuth = require("basic-auth");

const app = express();

const AUTH_USER = process.env.PROXY_USER || "proxyuser";
const AUTH_PASS = process.env.PROXY_PASS || "proxypass";

function requireAuth(req, res, next) {
  const user = basicAuth(req);
  if (!user || user.name !== AUTH_USER || user.pass !== AUTH_PASS) {
    res.set("WWW-Authenticate", 'Basic realm="Proxy"');
    return res.status(401).send("Authentication required.");
  }
  next();
}

app.use(rateLimit({
  windowMs: 60 * 1000,
  max: 60
}));

app.get("/", requireAuth, (req, res) => {
  res.send(`
    <h2>MegahackUnblocker</h2>
    <form action="/fetch" method="get">
      <input name="url" placeholder="https://example.com" style="width:70%" required>
      <button>Go</button>
    </form>
    <p>Use full URL including https://</p>
  `);
});

function isBlockedUrl(url) {
  return /(^https?:\/\/(localhost|127\.0\.0\.1|10\.|192\.168\.|172\.(1[6-9]|2\d|3[0-1])))/i.test(url);
}

app.get("/fetch", requireAuth, async (req, res) => {
  const target = req.query.url;
  if (!target) return res.status(400).send("Missing url parameter");
  if (isBlockedUrl(target)) return res.status(400).send("Blocked target");

  try {
    const response = await axios.get(target, {
      responseType: "arraybuffer",
      timeout: 20000,
      headers: { "User-Agent": "SimpleProxy/1.0" }
    });

    if (response.headers["content-type"]) res.set("Content-Type", response.headers["content-type"]);
    if (response.headers["content-length"]) res.set("Content-Length", response.headers["content-length"]);

    res.send(response.data);
  } catch (err) {
    console.error("Fetch error:", err.message);
    res.status(502).send("Upstream fetch error: " + err.message);
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Proxy running on port ${PORT}`));
